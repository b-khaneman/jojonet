# JOJOWARP

آنلاک خودکار **Gemini / Google Flow / ChatGPT / Claude / …** روی سرور خارج (Ubuntu)  
با Cloudflare WARP — **یک دستور، بدون پرسش**.

ریپو: https://github.com/b-khaneman/JOJOWARP  
پشتیبانی: [@B_khaneman](https://t.me/B_khaneman)  
نسخه: **1.1.1**

---

## نصب

روی سرور **خارج (Kharej)** که خروجی پنل از آن می‌رود:

```bash
curl -fsSL https://raw.githubusercontent.com/b-khaneman/JOJOWARP/main/install.sh | sudo bash
```

اگر GitHub فیلتر است:

```bash
curl -fsSL https://cdn.jsdelivr.net/gh/b-khaneman/JOJOWARP@main/install.sh | sudo bash
```

تمام. خودش پیش‌نیاز، WARP، روت AI، sticky IP و watchdog را اوکی می‌کند.

---

## با تانل + CDN کلودفلر

| چیز | وضعیت |
|-----|--------|
| کانفیگ تانل / پنل | دست‌نخورده |
| Cloudflare CDN | مستقیم می‌ماند |
| Gemini / Flow / ChatGPT / Claude / Android Studio / … | از WARP |

---

## دستورات

```bash
jojowarp status
jojowarp ip
jojowarp refresh
jojowarp uninstall --purge
```

(`ai-warp` هم همان دستور است.)

---

## حالت‌ها

پیش‌فرض: همه AIها (`ai`)

```bash
sudo bash install.sh --mode google
sudo bash install.sh --mode full
sudo bash install.sh --menu
```

---

License: MIT
